import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';
import { Router } from '@angular/router';

import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';

@Component({
  selector: 'news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.less']
})
export class NewsComponent implements OnInit {
  private title: string = '';
  private content: string = '';
  private showNews: boolean = false;

  news = [

    ];

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.NEWS');
  }

  ngOnInit() {
    this.listNews();
  }

  handleShowNews(news) {
    this.title = news.title;
    this.content = news.originalContent;
    this.showNews = true;
  }

  listNews() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/listNews?';
    url += 'activated=1';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list news failed.');

        return ;
      }

      this.news = [];
      data.news.forEach((news) => {
        news.picture =
          this.dataService.getRequestPrerfix() + '/store/download?name=' +
          news.picture;

        news.originalContent = news.content;
        if (news.content.length > 100) {
          news.content = news.content.substr(0, 100) + '...';
        }

        news.content = news.content.replace(/\r?\n/g, '<br />');
        news.originalContent = news.originalContent.replace(/\r?\n/g, '<br />');

        this.news.push(news);
      });
    });
  }

}
