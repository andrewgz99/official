import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';
import {HttpClient, HttpClientModule} from '@angular/common/http';

import {TranslateModule, TranslateLoader} from '@ngx-translate/core';

import { NgZorroAntdModule, NZ_I18N, zh_CN } from 'ng-zorro-antd';

import { HomeComponent } from './home/home.component';
import { ProductComponent }  from './product/product.component';
import { DefaultComponent }  from './default/default.component';
import { HelpComponent }  from './help/help.component';
import { NewsComponent }  from './news/news.component';
import { ContactComponent }  from './contact/contact.component';
import { CustomerComponent }  from './customer/customer.component';

import { MainRoutingModule }       from './main-routing.module';

@NgModule({
  imports: [
    TranslateModule.forChild(),
    CommonModule,
    HttpClientModule,

    NgZorroAntdModule,

    MainRoutingModule
  ],
  declarations: [
    HomeComponent,
    ProductComponent,
    DefaultComponent,
    HelpComponent,
    NewsComponent,
    ContactComponent,
    CustomerComponent
  ]
})
export class MainModule {}
