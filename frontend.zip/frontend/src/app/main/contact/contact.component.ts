import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

import { Router } from '@angular/router';

import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';

@Component({
  selector: 'contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.less']
})
export class ContactComponent implements OnInit {
  contacts = [

  ];

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.CONTACT');
  }

  listContact() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/contact/listContact?';
    url += 'activated=1';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list contact failed.');

        return ;
      }

      this.contacts = [];
      data.contacts.forEach((contact) => {
        if (contact.content.length > 100) {
          contact.content = contact.content.substr(0, 100) + '...';
        }

        this.contacts.push(contact);
      });
    });
  }

  ngOnInit() {
    this.listContact();
  }

}
