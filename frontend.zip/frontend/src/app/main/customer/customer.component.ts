import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

import { Router } from '@angular/router';

import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';

@Component({
  selector: 'customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.less']
})
export class CustomerComponent implements OnInit {

  customers = [


    ];

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.CUSTOMER');
  }

  ngOnInit() {
    this.listProduct();
  }

  listProduct() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/customer/listCustomer?';
    url += 'activated=1';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list customer failed.');

        return ;
      }

      this.customers = [];
      data.customers.forEach((customer) => {
        customer.originalContent = customer.content;
        if (customer.content.length > 100) {
          customer.content = customer.content.substr(0, 100) + '...';
        }

        customer.picture = this.dataService.getRequestPrerfix() +
          '/store/download?name=' + customer.picture;

        this.customers.push(customer);
      });
    });
  }
}
