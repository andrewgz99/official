import { Component, AfterViewInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

import { Router, ActivatedRoute } from '@angular/router';

import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';

@Component({
  selector: 'main-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.less']
})
export class DefaultComponent implements AfterViewInit {
  public currentLanguage = 'en';
  private languages = [
    {
      name: '简体中文'
    },
    {
      name: 'English'
    }
  ];

  private tabIndex: number = 0;

  constructor(private router: Router,
    private activatedRoute: ActivatedRoute,
    public translate: TranslateService,
    public languageService: LanguageService,
    public dataService: DataService) {

    this.currentLanguage = this.dataService.get("language");
  }

  setTabIndex(index) {
    this.tabIndex = index;
    console.log('tab index->' + this.tabIndex);
  }

  handleNav(event) {
    console.log('event->', event);

    if (0 == event.index) {
      this.router.navigate(['/home/index']);
    } else if (1 == event.index) {
      this.router.navigate(['/home/product']);
    } else if (2 == event.index) {
      this.router.navigate(['/home/news']);
    } else if (3 == event.index) {
      this.router.navigate(['/home/customer']);
    } else if (4 == event.index) {
      this.router.navigate(['/home/contact']);
    }

    this.tabIndex = event.index;

    console.log('tab index->' + this.tabIndex);
  }

  ngAfterViewInit() {
    setTimeout(() => {
      console.log('start to goto home...');
      this.router.navigate(['/home/index']);
    }, 1000);

  }

  handleLanguageChange(name) {
    console.log('name->' + name);

    this.dataService.set("language", name);
    this.languageService.change(this.translate, name);
    this.currentLanguage = name;

    window.location.reload(true);
  }

}
