import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { ProductComponent }  from './product/product.component';
import { DefaultComponent }  from './default/default.component';
import { HelpComponent }  from './help/help.component';
import { NewsComponent }  from './news/news.component';
import { ContactComponent }  from './contact/contact.component';
import { CustomerComponent }  from './customer/customer.component';

const mainRoutes: Routes = [
  {
    path: '',
    component: DefaultComponent,
    children: [
      {
        path: '',
        children: [
          { path: 'customer', component: CustomerComponent }
        ]
      },

      {
        path: '',
        children: [
          { path: 'product', component: ProductComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'index', component: HomeComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'support', component: HelpComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'news', component: NewsComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'contact', component: ContactComponent }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(mainRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class MainRoutingModule {}
