import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

import { Router } from '@angular/router';

import {LanguageService} from '../../common/language.service';

@Component({
  selector: 'main-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {

  constructor(private router: Router,
    public translate: TranslateService) {

    document.title = translate.instant('HOME.SUPPORT');
  }

  ngOnInit() {
  }

}
