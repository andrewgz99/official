import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

import { Router } from '@angular/router';

import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';
import {DefaultComponent} from '../default/default.component';

@Component({
  selector: 'main-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less']
})
export class HomeComponent implements OnInit {
  content: string = '';
  currentPicture: string = '';

  array = [1, 2, 3];
  carousels: any = [

  ];

  products = [

    ];

  news = [


    ];

    customers = [

      ];

  gotoCustomer() {
    window.scrollTo({ top: 0 });
    this.defaultComponent.setTabIndex(3);
  }

  gotoNews() {
    window.scrollTo({ top: 0 });
    this.defaultComponent.setTabIndex(2);
  }

  gotoProduct() {
    window.scrollTo({ top: 0 });
    this.defaultComponent.setTabIndex(1);
  }

  listNews() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/listNews?';
    url += 'activated=1';
    url += '&maxCount=4';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list news failed.');

        return ;
      }

      this.news = [];
      data.news.forEach((news) => {
        news.picture =
          this.dataService.getRequestPrerfix() + '/store/download?name=' +
          news.picture;
        this.news.push(news);
      });
    });
  }

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService,
    private defaultComponent: DefaultComponent) {

    document.title = translate.instant('HOME.HOME');
  }

  ngOnInit() {
    this.listCarousel();
    this.searchUs();
    this.listNews();
    this.listProduct();
    this.listCustomer();
  }

  listProduct() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/product/listProduct?';
    url += 'activated=1';
    url += '&maxCount=4';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list product failed.');

        return ;
      }

      this.products = [];
      data.products.forEach((product) => {
        product.originalContent = product.content;
        if (product.content.length > 100) {
          product.content = product.content.substr(0, 100) + '...';
        }

        product.picture = this.dataService.getRequestPrerfix() +
          '/store/download?name=' + product.picture;

        this.products.push(product);
      });
    });
  }

  searchUs() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/introduction/searchUs';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'search us failed.');

        return ;
      }

      this.content = data.introduction.content;
      this.currentPicture =
        this.dataService.getRequestPrerfix() + '/store/download';
      this.currentPicture += '?name=' + data.introduction.picture;
    });
  }

  listCarousel() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/listCarousel?';
    url += 'activated=1';
    url += '&maxCount=6';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list carousel failed.');

        return ;
      }

      this.carousels = [];
      data.carousels.forEach((carousel) => {
        carousel.picture = this.dataService.getRequestPrerfix() +
          '/store/download?name=' + carousel.picture;
        console.log('carousel->', carousel);
        this.carousels.push(carousel);
      })
    });
  }

  listCustomer() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/customer/listCustomer?';
    url += 'activated=1';
    url += '&maxCount=4';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list customer failed.');

        return ;
      }

      this.customers = [];
      data.customers.forEach((customer) => {
        if (customer.content.length > 100) {
          customer.content = customer.content.substr(0, 100) + '...';
        }

        customer.picture = this.dataService.getRequestPrerfix() +
          '/store/download?name=' + customer.picture;

        this.customers.push(customer);
      });
    });
  }
}
