import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

import { Router } from '@angular/router';

import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.less']
})
export class ProductComponent implements OnInit {

  products = [


    ];

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.PRODUCT');
  }

  ngOnInit() {
    this.listProduct();
  }

  listProduct() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/product/listProduct?';
    url += 'activated=1';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url)
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list product failed.');

        return ;
      }

      this.products = [];
      data.products.forEach((product) => {
        product.originalContent = product.content;
        if (product.content.length > 100) {
          product.content = product.content.substr(0, 100) + '...';
        }

        product.picture = this.dataService.getRequestPrerfix() +
          '/store/download?name=' + product.picture;

        this.products.push(product);
      });
    });
  }
}
