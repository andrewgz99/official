import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';
import { Router, ActivatedRoute } from '@angular/router';

import {LanguageService} from '../common/language.service';
import {DataService} from '../common/data.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {
  account: string = '';
  password: string = '';

  constructor(private router: Router,
      private http: HttpClient,
      private messageService: NzMessageService,
      private dataService: DataService) {

  }

  handleLogin() {
    console.log('start to login...');

    let url =
      this.dataService.getRequestPrerfix() + '/admin/login?';
    url += 'account=' + encodeURIComponent(this.account);
    url += '&password=' + encodeURIComponent(this.password);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'login failed.');

        return ;
      }

      this.router.navigate(['/admin']);
    });


  }

  ngOnInit(): void {

  }

}
