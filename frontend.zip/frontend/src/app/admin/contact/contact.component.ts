import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

import { Router } from '@angular/router';

import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';

@Component({
  selector: 'admin-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.less']
})
export class ContactComponent implements OnInit {
  id: number = 0;
  title: string = 'hello';
  picture: string = '';
  content: string = '';
  currentData: any = {};
  removingData: any = null;

  showDialog: boolean = false;

  showConfirmDialog: boolean = false;

  showAddDialog: boolean = false;

  listOfData = [

    ];

  handleUploadResult(event) {
    console.log('upload result->', event);

    if ('start' == event.type) {
      return ;
    }

    if ('progress' == event.type) {
      return ;
    }

    if ('success' != event.type) {
      this.messageService.create('error', 'upload picture failed.');

      return ;
    }

    this.messageService.create('info', 'upload picture ok.');
  }

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.NEWS');
  }

  handleContact() {
    console.log('start to add new news...');

    let url =
      this.dataService.getRequestPrerfix() + '/admin/contact/addContact?';
    url += 'title=' + encodeURIComponent(this.title);
    url += '&content=' + encodeURIComponent(this.content);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'create contact failed.');

        return ;
      }

      this.messageService.create('info', 'create contact ok.');

      this.listContact();
    });
  }

  handleAddContact() {
    this.title = '';
    this.picture = '';
    this.content = '';

    this.showAddDialog = true;
  }

  handleSaveContact() {
    console.log('title->', this.title,
    ', picture->', this.picture, ', content->', this.content);

    this.currentData.title = this.title;
    this.currentData.picture = this.picture;
    this.currentData.content = this.content;

    let url =
      this.dataService.getRequestPrerfix() + '/admin/contact/updateContact?';
    url += 'id=' + this.id;
    url += '&title=' + encodeURIComponent(this.title);
    url += '&content=' + encodeURIComponent(this.content);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'update contact failed.');

        return ;
      }

      this.messageService.create('info', 'update contact ok.');

      this.listContact();
    });
  }


  handleActivate(contact) {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/contact/activateContact?';
    url += 'id=' + encodeURIComponent(contact.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'activate contact failed.');

        return ;
      }

      contact.activated = 1;
    });
  }

  handleEdit(data) {
    console.log('edit data...', data);

    this.id = data.id;
    this.title = data.title;
    this.picture = data.picture;
    this.content = data.content;

    this.currentData = data;

    this.showDialog = true;
  }

  handleConfirmRemove() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/contact/removeContact?';
    url += 'id=' + encodeURIComponent(this.removingData.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'remove contact failed.');

        return ;
      }

      this.listContact();
    });
  }

  handleRemove(data) {
    console.log('remove data...');

    this.removingData = data;

    this.showConfirmDialog = true;
  }

  listContact() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/contact/listContact?';
    url += 'activated=0';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list contact failed.');

        return ;
      }

      this.listOfData = [];
      data.contacts.forEach((contact) => {
        if (contact.content.length > 100) {
          contact.content = contact.content.substr(0, 100) + '...';
        }

        this.listOfData.push(contact);
      });
    });
  }

  ngOnInit() {
    this.listContact();
  }

}
