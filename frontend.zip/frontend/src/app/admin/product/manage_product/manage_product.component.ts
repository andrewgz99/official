import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

import { Router } from '@angular/router';

import {LanguageService} from '../../../common/language.service';
import {DataService} from '../../../common/data.service';

@Component({
  selector: 'news-manage_product',
  templateUrl: './manage_product.component.html',
  styleUrls: ['./manage_product.component.less']
})
export class ManageProductComponent implements OnInit {
  id: number = 0;
  title: string = 'hello';
  picture: string = '';
  content: string = '';
  currentData: any = {};
  removingData: any = null;

  showDialog: boolean = false;

  showConfirmDialog: boolean = false;

  showAddDialog: boolean = false;

  listOfData = [

    ];

  private fileList: any = [];

  private currentPicture: string = '';

  private uploadPictureUrl: string = '';

  handleUploadResult(event) {
    console.log('upload result->', event);

    if ('start' == event.type) {
      return ;
    }

    if ('progress' == event.type) {
      return ;
    }

    if ('success' != event.type) {
      this.messageService.create('error', 'upload picture failed.');

      return ;
    }

    this.messageService.create('info', 'upload picture ok.');

    this.fileList = [
      this.fileList[this.fileList.length - 1]
    ];
    this.currentPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentPicture += '?name=product.tmp';
    console.log('new tmp url->', this.currentPicture);
  }

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.NEWS');

    this.uploadPictureUrl = this.dataService.getRequestPrerfix() +
      '/store/upload?name=product.tmp';
  }

  handleProduct() {
    console.log('start to add new news...');

    let url =
      this.dataService.getRequestPrerfix() + '/admin/product/addProduct?';
    url += 'title=' + encodeURIComponent(this.title);
    url += '&content=' + encodeURIComponent(this.content);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'create product failed.');

        return ;
      }

      this.messageService.create('info', 'create product ok.');

      this.listProduct();
    });
  }

  handleAddProduct() {
    this.title = '';
    this.picture = '';
    this.content = '';
    this.currentPicture = '';

    this.showAddDialog = true;
  }

  handleSaveProduct() {
    console.log('title->', this.title,
    ', picture->', this.picture, ', content->', this.content);

    this.currentData.title = this.title;
    this.currentData.picture = this.picture;
    this.currentData.content = this.content;

    let url =
      this.dataService.getRequestPrerfix() + '/admin/product/updateProduct?';
    url += 'id=' + this.id;
    url += '&title=' + encodeURIComponent(this.title);
    url += '&content=' + encodeURIComponent(this.content);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'update product failed.');

        return ;
      }

      this.messageService.create('info', 'update product ok.');

      this.listProduct();
    });
  }


  handleActivate(product) {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/product/activateProduct?';
    url += 'id=' + encodeURIComponent(product.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'activate product failed.');

        return ;
      }

      product.activated = 1;
    });
  }

  handleEdit(data) {
    console.log('edit data...', data);

    this.currentPicture = '';

    this.id = data.id;
    this.title = data.title;
    this.picture = data.picture;
    this.content = data.content;

    this.currentData = data;

    this.currentPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentPicture += '?name=' + data.picture;
    console.log('url->' + this.currentPicture);

    this.showDialog = true;
  }

  handleConfirmRemove() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/product/removeProduct?';
    url += 'id=' + encodeURIComponent(this.removingData.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'remove product failed.');

        return ;
      }

      this.listProduct();
    });
  }

  handleRemove(data) {
    console.log('remove data...');

    this.removingData = data;

    this.showConfirmDialog = true;
  }

  listProduct() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/product/listProduct?';
    url += 'activated=0';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list product failed.');

        return ;
      }

      this.listOfData = [];
      data.products.forEach((product) => {
        if (product.content.length > 100) {
          product.content = product.content.substr(0, 100) + '...';
        }

      //  product.content = product.content.replace(/\r?\n/g, '<br />');

        this.listOfData.push(product);
      });
    });
  }

  ngOnInit() {
    this.listProduct();
  }

}
