import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';

import { NzMessageService } from 'ng-zorro-antd';


import {LanguageService} from '../../../common/language.service';
import {DataService} from '../../../common/data.service';


@Component({
  selector: 'news-manage_carousel',
  templateUrl: './manage_carousel.component.html',
  styleUrls: ['./manage_carousel.component.less']
})
export class ManageCarouselComponent implements OnInit {
  id: number = 0;
  title: string = 'hello';
  picture: string = '';
  content: string = '';
  currentData: any = {};
  uploadCarouselUrl: string = '';
  currentCourselPicture: string = '';
  fileList: any = [];
  showConfirmDialog = false;
  removingData: any = null;

  showDialog: boolean = false;

  showAddDialog: boolean = false;

  listOfData = [

  ];

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.NEWS');

    this.uploadCarouselUrl = this.dataService.getRequestPrerfix() +
      '/store/upload?name=carousel.tmp';
  }

  handleUploadCarouselResult(event) {
    console.log('upload carousel result->', event);

    if ('start' == event.type) {
      return ;
    }

    if ('progress' == event.type) {
      return ;
    }

    if ('success' != event.type) {
      this.messageService.create('error', 'upload carousel failed.');

      return ;
    }

    this.messageService.create('info', 'upload carousel ok.');

    this.fileList = [
      this.fileList[this.fileList.length - 1]
    ];
    this.currentCourselPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentCourselPicture += '?name=carousel.tmp';
    console.log('new tmp url->', this.currentCourselPicture);
  }

  listCarousel() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/listCarousel?';
    url += 'activated=0';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list carousel failed.');

        return ;
      }

      this.listOfData = data.carousels;
    });
  }

  handleCarousel() {
    console.log('start to add new news...');

    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/addCarousel?';
    url += 'title=' + encodeURIComponent(this.title);
    url += '&picture=' + encodeURIComponent(this.picture);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'create carousel failed.');

        return ;
      }

      this.messageService.create('info', 'create carousel ok.');

      this.listCarousel();
    });
  }

  handleAddCarousel() {
    this.title = '';
    this.picture = '';
    this.content = '';

    this.currentCourselPicture = '';

    this.showAddDialog = true;
  }

  handleSaveCarouselResult(event) {
    if ('start' == event.type) {
      return ;
    }

    if ('progress' == event.type) {
      return ;
    }

    if ('success' != event.type) {
      this.messageService.create('error', 'upload carousel failed.');

      return ;
    }

    this.fileList = [
      this.fileList[this.fileList.length - 1]
    ];
    this.currentCourselPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentCourselPicture += '?name=carousel.tmp';
    console.log('new tmp url->', this.currentCourselPicture);
  }

  handleUpdateCarousel() {
    console.log('id->' + this.id + ', title->', this.title,
    ', picture->', this.picture, ', content->', this.content);

    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/updateCarousel?';
    url += 'id=' + this.id;
    url += '&title=' + encodeURIComponent(this.title);
    url += '&picture=' + encodeURIComponent(this.picture);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'update carousel failed.');

        return ;
      }

      this.messageService.create('info', 'update carousel ok.');

      this.listCarousel();
    });
  }

  handleEdit(data) {
    console.log('edit data...', data);

    this.id = data.id;
    this.title = data.title;
    this.picture = data.picture;
    this.content = data.content;
    this.fileList = [];

    this.currentData.id = data.id;
    this.currentData.title = data.title;
    this.currentData.picture = data.picture;
    this.currentData.content = data.content;

    this.currentCourselPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentCourselPicture += '?name=' + data.picture;
    console.log('url->' + this.currentCourselPicture);

    this.showDialog = true;
  }

  handleConfirmRemove() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/removeCarousel?';
    url += 'id=' + encodeURIComponent(this.removingData.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'remove carousel failed.');

        return ;
      }

      this.listCarousel();
    });
  }

  handleRemove(data) {
    console.log('remove data...');

    this.removingData = data;
    this.showConfirmDialog = true;
  }

  handleActivate(carousel) {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/activateCarousel?';
    url += 'id=' + encodeURIComponent(carousel.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'activate carousel failed.');

        return ;
      }

      carousel.activated = 1;
    });
  }

  ngOnInit() {
    this.listCarousel();
  }


}
