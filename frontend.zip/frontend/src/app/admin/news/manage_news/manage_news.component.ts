import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { NzMessageService } from 'ng-zorro-antd';

import { Router } from '@angular/router';

import {LanguageService} from '../../../common/language.service';
import {DataService} from '../../../common/data.service';

@Component({
  selector: 'news-manage_news',
  templateUrl: './manage_news.component.html',
  styleUrls: ['./manage_news.component.less']
})
export class ManageNewsComponent implements OnInit {
  id: number = 0;
  title: string = 'hello';
  picture: string = '';
  content: string = '';
  currentData: any = {};
  removingData: any = null;

  showDialog: boolean = false;

  showConfirmDialog: boolean = false;

  showAddDialog: boolean = false;

  listOfData = [

    ];

  private fileList: any = [];

  private currentPicture: string = '';

  private uploadPictureUrl: string = '';

  handleUploadResult(event) {
    console.log('upload result->', event);

    if ('start' == event.type) {
      return ;
    }

    if ('progress' == event.type) {
      return ;
    }

    if ('success' != event.type) {
      this.messageService.create('error', 'upload picture failed.');

      return ;
    }

    this.messageService.create('info', 'upload picture ok.');

    this.fileList = [
      this.fileList[this.fileList.length - 1]
    ];
    this.currentPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentPicture += '?name=news.tmp';
    console.log('new tmp url->', this.currentPicture);
  }

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.NEWS');

    this.uploadPictureUrl = this.dataService.getRequestPrerfix() +
      '/store/upload?name=news.tmp';
  }

  handleNews() {
    console.log('start to add new news...');

    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/addNews?';
    url += 'title=' + encodeURIComponent(this.title);
    url += '&content=' + encodeURIComponent(this.content);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'create news failed.');

        return ;
      }

      this.messageService.create('info', 'create news ok.');

      this.listNews();
    });
  }

  handleAddNews() {
    this.title = '';
    this.picture = '';
    this.content = '';
    this.currentPicture = '';

    this.showAddDialog = true;
  }

  handleSaveNews() {
    console.log('title->', this.title,
    ', picture->', this.picture, ', content->', this.content);

    this.currentData.title = this.title;
    this.currentData.picture = this.picture;
    this.currentData.content = this.content;

    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/updateNews?';
    url += 'id=' + this.id;
    url += '&title=' + encodeURIComponent(this.title);
    url += '&content=' + encodeURIComponent(this.content);
    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'update news failed.');

        return ;
      }

      this.messageService.create('info', 'update news ok.');

      this.listNews();
    });
  }


  handleActivate(news) {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/activateNews?';
    url += 'id=' + encodeURIComponent(news.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'activate news failed.');

        return ;
      }

      news.activated = 1;
    });
  }

  handleEdit(data) {
    console.log('edit data...', data);

    this.currentPicture = '';

    this.id = data.id;
    this.title = data.title;
    this.picture = data.picture;
    this.content = data.content;

    this.currentData = data;

    this.currentPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentPicture += '?name=' + data.picture;
    console.log('url->' + this.currentPicture);

    this.showDialog = true;
  }

  handleConfirmRemove() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/removeNews?';
    url += 'id=' + encodeURIComponent(this.removingData.id);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'remove news failed.');

        return ;
      }

      this.listNews();
    });
  }

  handleRemove(data) {
    console.log('remove data...');

    this.removingData = data;

    this.showConfirmDialog = true;
  }

  listNews() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/news/listNews?';
    url += 'activated=0';
    url += '&maxCount=1000';

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'list news failed.');

        return ;
      }

      this.listOfData = [];
      data.news.forEach((news) => {
        if (news.content.length > 100) {
          news.content = news.content.substr(0, 100) + '...';
        }

        news.content = news.content.replace(/\r?\n/g, '<br />');

        this.listOfData.push(news);
      });
    });
  }

  ngOnInit() {
    this.listNews();
  }

}
