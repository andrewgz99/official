import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import {LanguageService} from '../../common/language.service';
import {DataService} from '../../common/data.service';


@Component({
  selector: 'admin-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.less']
})
export class DefaultComponent {
  isCollapsed: boolean = false;

  constructor(private router: Router,
    public translate: TranslateService,
    public languageService: LanguageService,
    public dataService: DataService) {
    setTimeout(() => {
      console.log('start to goto home...');
      this.router.navigate(['/admin/manage_us']);
    }, 1000);
  }

  handleNav(name: string) {
    if ('manage_carousel' == name) {
      this.router.navigate(['/admin/manage_carousel']);
    }
    if ('manage_news' == name) {
      this.router.navigate(['/admin/manage_news']);
    }
    if ('manage_product' == name) {
      this.router.navigate(['/admin/manage_product']);
    }
    if ('manage_customer' == name) {
      this.router.navigate(['/admin/manage_customer']);
    }
    if ('manage_contact' == name) {
      this.router.navigate(['/admin/manage_contact']);
    }

    if ('manage_introduction' == name) {
      this.router.navigate(['/admin/manage_us']);
    }

  }

  handleTab(event) {
    console.log('event->', event);
  }
}
