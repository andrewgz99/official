import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import {TranslateModule, TranslateLoader} from '@ngx-translate/core';

import { NgZorroAntdModule, NZ_I18N, zh_CN } from 'ng-zorro-antd';

import { ManageCarouselComponent } from './news/manage_carousel/manage_carousel.component';
import { DefaultComponent }  from './default/default.component';
import { ManageNewsComponent }  from './news/manage_news/manage_news.component';
import { ManageProductComponent }  from './product/manage_product/manage_product.component';
import { ContactComponent }  from './contact/contact.component';
import { ManageUsComponent }  from './introduction/manage_us/manage_us.component';
import { CustomerComponent }  from './customer/customer.component';

import { AdminRoutingModule }       from './admin-routing.module';

@NgModule({
  imports: [
    TranslateModule.forChild(),
    CommonModule,
    FormsModule,
    HttpClientModule,

    NgZorroAntdModule,

    AdminRoutingModule
  ],
  declarations: [
    ManageCarouselComponent,
    DefaultComponent,
    ManageNewsComponent,
    ManageProductComponent,
    CustomerComponent,
    ContactComponent,
    ManageUsComponent,
    CustomerComponent
  ]
})
export class AdminModule {}
