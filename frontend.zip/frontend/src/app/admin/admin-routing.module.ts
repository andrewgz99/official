import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DefaultComponent } from './default/default.component';
import { ManageCarouselComponent } from './news/manage_carousel/manage_carousel.component';
import { ManageNewsComponent }  from './news/manage_news/manage_news.component';
import { ManageProductComponent }  from './product/manage_product/manage_product.component';
import { ContactComponent }  from './contact/contact.component';
import { ManageUsComponent }  from './introduction/manage_us/manage_us.component';
import { CustomerComponent }  from './customer/customer.component';

const adminRoutes: Routes = [
  {
    path: '',
    component: DefaultComponent,
    children: [
      {
        path: '',
        children: [
          { path: 'manage_customer', component: CustomerComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'manage_us', component: ManageUsComponent }
        ]
      },

      {
        path: '',
        children: [
          { path: 'manage_contact', component: ContactComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'manage_customer', component: CustomerComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'manage_carousel', component: ManageCarouselComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'manage_news', component: ManageNewsComponent }
        ]
      },
      {
        path: '',
        children: [
          { path: 'manage_product', component: ManageProductComponent }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(adminRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AdminRoutingModule {}
