import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {HttpClient} from '@angular/common/http';
import { Router } from '@angular/router';

import { NzMessageService } from 'ng-zorro-antd';


import {LanguageService} from '../../../common/language.service';
import {DataService} from '../../../common/data.service';


@Component({
  selector: 'introduction-manage_us',
  templateUrl: './manage_us.component.html',
  styleUrls: ['./manage_us.component.less']
})
export class ManageUsComponent implements OnInit {
  private currentPicture: string = '';

  private uploadPictureUrl: string = '';

  private content: string = '';

  private fileList: any = [];

  private activated: number = 0;

  private copyRight: string = '';

  handleActivate() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/introduction/activate';

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'activate us failed.');

        return ;
      }

      this.messageService.create('info', 'activate us ok.');

      this.activated = 1;
    });
  }

  handleChange() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/introduction/change';
    url += '?content=' + encodeURIComponent(this.content);
    url += '&copyRight=' + encodeURIComponent(this.copyRight);

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'change us failed.');

        return ;
      }

      this.messageService.create('info', 'change us ok.');

      this.searchUs();
    });
  }

  handleUploadResult(event) {
    this.fileList = [
      this.fileList[this.fileList.length - 1]
    ];

    if ('start' == event.type) {
      return ;
    }

    if ('progress' == event.type) {
      return ;
    }

    if ('success' != event.type) {
      this.messageService.create('error', 'upload picture failed.');

      return ;
    }

    this.messageService.create('info', 'upload picture ok.');

    this.currentPicture =
      this.dataService.getRequestPrerfix() + '/store/download';
    this.currentPicture += '?name=introduction.tmp';
    console.log('new tmp url->', this.currentPicture);
  }

  constructor(private router: Router,
    public translate: TranslateService,
    private http: HttpClient,
    private messageService: NzMessageService,
    private dataService: DataService) {

    document.title = translate.instant('HOME.US');

    this.uploadPictureUrl = this.dataService.getRequestPrerfix() +
      '/store/upload?name=introduction.tmp';
  }

  searchUs() {
    let url =
      this.dataService.getRequestPrerfix() + '/admin/introduction/searchUs';

    console.log('url->' + url);

    this.http.get(url, {withCredentials: true})
    .subscribe((data: any) => {
      console.log('data->', data);
      if (0 != data.code) {
        this.messageService.create('error', 'search us failed.');

        return ;
      }

      this.activated = data.introduction.activated;
      this.copyRight = data.introduction.copyRight;
      this.content = data.introduction.content;
      this.currentPicture =
        this.dataService.getRequestPrerfix() + '/store/download';
      this.currentPicture += '?name=' + data.introduction.picture;
    });
  }

  ngOnInit() {
    this.searchUs();
  }


}
