import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import {TranslateService} from '@ngx-translate/core';
import {DataService} from './common/data.service';
import {LanguageService} from './common/language.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'eshopping';
  size = 'large';

  constructor(private router: Router,
   public translate: TranslateService,
   public dataService: DataService,
   public languageService: LanguageService) {

  }

  ngOnInit() {
    setTimeout(() => {
      this.languageService.change(this.translate,
        this.dataService.get("language"));
      console.log('url->', this.router.url);
      if ('/login' == this.router.url
        || '/admin' == this.router.url
        || '/admin/news' == this.router.url) {

      } else {
      //  this.router.navigate(['/home']);
      }

    }, 1000);
  }
}
