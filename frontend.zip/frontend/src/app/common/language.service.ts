import { Injectable } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Injectable({
  providedIn: 'root',
})
export class LanguageService {
  change(translater: TranslateService, name: string) {
    if ('en' == name) {
      console.log('set english...');
      translater.use('en');
    } else {
      console.log('set chinese...');
      translater.use('zh_cn');
    }

  }
}
