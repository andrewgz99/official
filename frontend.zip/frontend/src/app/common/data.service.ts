import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DataService {

  constructor() {
    console.log('start to init database...');

  }

  getRequestPrerfix(): string {
    if (environment.production) {
      return "";
    } else {
      return "http://192.168.43.189:8080";
    }
  }

  set(key, value) {
    localStorage.setItem(key, value);
  }

  get(key): any {
    return localStorage.getItem(key);
  }
}
