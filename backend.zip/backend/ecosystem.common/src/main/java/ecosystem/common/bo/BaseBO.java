package ecosystem.common.bo;

import java.io.Serializable;

public class BaseBO implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Long userId;
    
    private String account;
    
    private String password;
    
    private String token;
    
    private String tableName;
    
    public BaseBO() {
        userId = -1L;
        
        token = "";
        
        tableName = "";
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
}
