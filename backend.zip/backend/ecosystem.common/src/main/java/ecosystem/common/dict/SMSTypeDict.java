package ecosystem.common.dict;

public enum SMSTypeDict {
    REGIST("regist"), 
    RESETPWD("resetpwd"), 
    CHANGEPWD("changepwd");
    
    private String type;
    
    SMSTypeDict(String type) {
        this.type = type;
    }
    
    public String getType() {
        return this.type;
    }
}
