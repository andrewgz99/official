package ecosystem.common.dict;

public enum CommonErrorDict {
    OK(0, "成功！"), 
    UNKNOWN(-1, "未知错误！"), 
    PARAMETER(-2, "参数错误！"), 
    DENIED(-3, "无权访问！"), 
    DATABASE(-4, "系统错误！"), 
    NODATA(-5, "没有数据！"), 
    OVERRANGE(-6, "访问越界！"), 
    SYSTEM(-7, "系统错误！"), 
    RPC(-8, "服务错误！"), 
    EXISTS(-9, "已经存在！"), 
    LOCKED(-10, "帐号被冻结！");
    
    private Integer code;
    
    private String description;
    
    CommonErrorDict(Integer code, String description) {
        this.code = code;
        this.description = description;
    }
    
    public Integer getCode() {
        return this.code;
    }
    
    public String getDescription() {
        return this.description;
    }
}
