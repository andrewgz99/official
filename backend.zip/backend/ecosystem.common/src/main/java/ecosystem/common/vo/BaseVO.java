package ecosystem.common.vo;

import java.io.Serializable;

import ecosystem.common.dict.CommonErrorDict;

public class BaseVO implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer code;
    
    private String description;

    public BaseVO() {
        this.code = CommonErrorDict.UNKNOWN.getCode();
        this.description = CommonErrorDict.UNKNOWN.getDescription();
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
}
