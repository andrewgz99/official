package ecosystem.eshopping.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import ecosystem.eshopping.model.dto.UserDTO;

@Repository
public interface InitializerDAO {
	int initUser(@Param("user") UserDTO user);
	
	int createUser();
	
	int createNews();
	
	int createCarousel();
	
	int createProduct();
	
	int createContact();
	
	int createCustomer();
	
	int createIntroduction();
}
