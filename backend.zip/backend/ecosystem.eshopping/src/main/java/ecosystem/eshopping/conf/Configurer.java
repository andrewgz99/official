package ecosystem.eshopping.conf;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import ecosystem.eshopping.Application;
import ecosystem.eshopping.dao.InitializerDAO;
import ecosystem.eshopping.dao.IntroductionDAO;
import ecosystem.eshopping.dao.UserDAO;
import ecosystem.eshopping.model.dto.IntroductionDTO;
import ecosystem.eshopping.model.dto.UserDTO;

@Configuration
public class Configurer implements InitializingBean {
	private Logger logger = LoggerFactory.getLogger(Configurer.class);
	
	@Autowired
	private InitializerDAO initializerDAO;
	
	@Autowired
	private IntroductionDAO introductionDAO;
	
	@Autowired
	private UserDAO userDAO;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		initializerDAO.createUser();
		if (null == userDAO.search("admin")) {
			UserDTO user = new UserDTO();
			user.setAccount("admin");
			user.setPassword(DigestUtils.sha256Hex("123456"));
			user.setDateline(System.currentTimeMillis());
			initializerDAO.initUser(user);	
		}
		
		initializerDAO.createNews();
		initializerDAO.createCarousel();
		initializerDAO.createIntroduction();
		initializerDAO.createContact();
		initializerDAO.createProduct();
		initializerDAO.createCustomer();
		
		if (null != introductionDAO.search()) {
			return ;
		}
		
		IntroductionDTO introduction = new IntroductionDTO();
		introduction.setActivated(0);
		introduction.setContent("test");
		introduction.setCopyRight("copy right.");
		introduction.setPicture("picture");
		int result = introductionDAO.add(introduction);
		if (1 != result) {
			logger.error("initialize introduction failed...");
		}
	}
	
}
