package ecosystem.eshopping.controller;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.vo.ProductsVO;
import reactor.core.publisher.Mono;

public interface ProductController {
	Mono<BaseVO> handleAddProduct();
	
	Mono<ProductsVO> handleSearchProducts(int maxCount);
}
