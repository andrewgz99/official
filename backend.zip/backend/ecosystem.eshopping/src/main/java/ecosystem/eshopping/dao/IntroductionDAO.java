package ecosystem.eshopping.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import ecosystem.eshopping.model.dto.IntroductionDTO;

@Repository
public interface IntroductionDAO {
	int activate();
	
	IntroductionDTO search();
	
	int add(@Param("introduction") IntroductionDTO introduction);
	
	int update(@Param("introduction") IntroductionDTO introduction);
}
