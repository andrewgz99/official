package ecosystem.eshopping.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.multipart.MultipartFile;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.CarouselDTO;
import ecosystem.eshopping.model.vo.ListCarouselVO;
import reactor.core.publisher.Mono;

public interface NewsController {
	Mono<BaseVO> activateCarousel(int id);
	
	Mono<ListCarouselVO> listCarousel(int activated, int maxCount);
	
	Mono<BaseVO> removeCarousel(int id);
	
	Mono<BaseVO> addCarousel(CarouselDTO carousel);
	
	Mono<BaseVO> saveCarousel(CarouselDTO carousel);
	
	Mono<BaseVO> uploadCarousel(MultipartFile file);
	
	public byte[] downloadCarousel(HttpServletResponse response, String name);
}
