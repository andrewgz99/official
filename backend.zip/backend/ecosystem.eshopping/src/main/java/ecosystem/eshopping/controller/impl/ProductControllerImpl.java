package ecosystem.eshopping.controller.impl;

import java.io.File;
import java.io.IOException;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ZeroCopyHttpOutputMessage;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.http.codec.multipart.Part;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;

import ecosystem.common.dict.CommonErrorDict;
import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.controller.ProductController;
import ecosystem.eshopping.model.bo.ProductBO;
import ecosystem.eshopping.model.dto.ProductDTO;
import ecosystem.eshopping.model.vo.ProductsVO;
import ecosystem.eshopping.service.ProductService;
import ecosystem.eshopping.service.impl.ProductServiceImpl;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@CrossOrigin(
	    origins = {"*"},
	    maxAge = 3600,
	    allowCredentials = "true")
@RestController
@RequestMapping("/product")
public class ProductControllerImpl implements ProductController {
	private Logger logger = LoggerFactory.getLogger(ProductControllerImpl.class);
	
	@Autowired
	private ProductServiceImpl productService;
	
    @RequestMapping(
    		value = "/download", 
    		method = RequestMethod.GET, 
    		consumes = "application/json")
    public Mono<Void> downloadByWriteWith(ServerHttpResponse response) {
    	Mono<Void> retValue = null;
    	
        ZeroCopyHttpOutputMessage zeroCopyResponse = (ZeroCopyHttpOutputMessage) response;
        response.getHeaders().set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=parallel.png");
        response.getHeaders().setContentType(MediaType.IMAGE_PNG);

        Resource resource = new ClassPathResource("parallel.png");
        File file;
		try {
			file = resource.getFile();
			retValue = zeroCopyResponse.writeWith(file, 0, file.length());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		return retValue;
    }
	
    @PostMapping(value = "/upload", 
    		consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
    		produces = MediaType.APPLICATION_JSON_VALUE)
    String saveImage(@RequestParam("file") MultipartFile file) throws Exception{
         return "test";
    }
    
    @PostMapping(value = "/upload2", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<String> handleUploadFile(@RequestBody Flux<Part> parts) {
    	if (logger.isDebugEnabled()) {
    		logger.debug("file name->{}", parts.blockFirst().name());
    	}
    	/**
    	 * System.out.println(filePart.filename());
        Path tempFile = Files.createTempFile("test", filePart.filename());

        //NOTE 方法一
        AsynchronousFileChannel channel =
                AsynchronousFileChannel.open(tempFile, StandardOpenOption.WRITE);
        DataBufferUtils.write(filePart.content(), channel, 0)
                .doOnComplete(() -> {
                    System.out.println("finish");
                })
            .subscribe();

        //NOTE 方法二
//        filePart.transferTo(tempFile.toFile());

        System.out.println(tempFile.toString());
        return Mono.just(filePart.filename());
    	 */
    	return Mono.just(parts.blockFirst().name());
    }
    
    
    @RequestMapping(
    		value = "/updateProduct", 
    		method = RequestMethod.POST, 
    		consumes="application/json", 
    		produces="application/json")
    public Flux<BaseVO> handleUpdateProduct(@RequestBody ProductBO product) {
    	if (logger.isDebugEnabled()) {
    		logger.debug("product->{}", JSON.toJSONString(product));
    	}

    	return Flux.just(new BaseVO());
    }
    
    
    public Flux<ProductDTO> handleListProduct() {

    	return Flux.just(new ProductDTO());
    }

    
    @GetMapping("/addProduct")
	@Override
	public Mono<BaseVO> handleAddProduct() {
		// TODO Auto-generated method stub
    	BaseVO retValue = new BaseVO();
    	
    	
    	
		return Mono.just(retValue);
	}

	@Override
	public Mono<ProductsVO> handleSearchProducts(int maxCount) {
		// TODO Auto-generated method stub
		return null;
	}
}
