package ecosystem.eshopping.controller.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import ecosystem.common.dict.CommonErrorDict;
import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.CarouselDTO;
import ecosystem.eshopping.model.dto.ContactDTO;
import ecosystem.eshopping.model.dto.CustomerDTO;
import ecosystem.eshopping.model.dto.IntroductionDTO;
import ecosystem.eshopping.model.dto.NewsDTO;
import ecosystem.eshopping.model.dto.ProductDTO;
import ecosystem.eshopping.model.dto.UserDTO;
import ecosystem.eshopping.model.vo.IntroductionVO;
import ecosystem.eshopping.model.vo.ListCarouselVO;
import ecosystem.eshopping.model.vo.ListContactVO;
import ecosystem.eshopping.model.vo.ListCustomerVO;
import ecosystem.eshopping.model.vo.ListNewsVO;
import ecosystem.eshopping.model.vo.ListProductVO;
import ecosystem.eshopping.service.NewsService;
import ecosystem.eshopping.service.impl.ContactServiceImpl;
import ecosystem.eshopping.service.impl.CustomerServiceImpl;
import ecosystem.eshopping.service.impl.IntroductionServiceImpl;
import ecosystem.eshopping.service.impl.ProductServiceImpl;
import ecosystem.eshopping.service.impl.UserServiceImpl;
import reactor.core.publisher.Mono;

@CrossOrigin(
	    origins = {"*"},
	    maxAge = 3600,
	    allowCredentials = "true")
@RestController
@RequestMapping("/admin")
public class AdminControllerImpl {
	@Value("${store.path}")
	private String storePath;
	
	@Autowired
	private CustomerServiceImpl customerService;
	
	@Autowired
	private NewsService newsService;
	
	@Autowired
	private ProductServiceImpl productService;
	
	@Autowired
	private IntroductionServiceImpl introductionService;
	
	@Autowired
	private ContactServiceImpl contactService;
	
	@Autowired
	private UserServiceImpl userService;
	
    @RequestMapping(
    		value = "/login", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> login(
			HttpServletRequest request, 
			@RequestParam("account") String account, 
			@RequestParam("password") String password
			) {
    	BaseVO retValue = new BaseVO();
    	
    	HttpSession session = request.getSession();
    	
    	UserDTO user = userService.searchUser(account);
    	String requestPassword = DigestUtils.sha256Hex(password);
    	if (null == user || !user.getPassword().equals(requestPassword)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
    		
    		session.removeAttribute("token");
    		
    		return Mono.just(retValue);
    	}
    	
    	
    	if (isLogin(request)) {
    		retValue.setCode(CommonErrorDict.OK.getCode());
    		
    		return Mono.just(retValue);
    	}
    	
    	session.setAttribute("token", 
    			UUID.nameUUIDFromBytes(account.getBytes()).toString().replaceAll("-", ""));
    	retValue.setCode(CommonErrorDict.OK.getCode());
    	
    	return Mono.just(retValue);
    }
	
    @RequestMapping(
    		value = "/introduction/activate", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> activateUs(HttpServletRequest request) {
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (!introductionService.activate()) {
    		retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
    	return Mono.just(retValue);
    }
    
    @RequestMapping(
    		value = "/introduction/change", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> changeUs(
			HttpServletRequest request, 
			@RequestParam("content") String content, 
			@RequestParam("copyRight") String copyRight) {
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (content.isEmpty()) {
    		retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("content " + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (copyRight.isEmpty()) {
    		retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("copy right " + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	content = StringEscapeUtils.escapeHtml4(content);
    	copyRight = StringEscapeUtils.escapeHtml4(copyRight);
    	
    	IntroductionDTO introduction = new IntroductionDTO();
    	introduction.setContent(content);
    	introduction.setCopyRight(copyRight);
    	if (!introductionService.change(introduction)) {
    		retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
    	return Mono.just(retValue);
    }
    
    @RequestMapping(
    		value = "/introduction/searchUs", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> searchUs(HttpServletRequest request) {
    	IntroductionVO retValue = new IntroductionVO();
    	
    	IntroductionDTO introduction = introductionService.searchUs();
    	if (null == introduction) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	retValue.setIntroduction(introduction);
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
    	return Mono.just(retValue);
    }
    
    //--------------------------------------carousel-------------------------------->
    @RequestMapping(
    		value = "/news/addCarousel", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> addCarousel(
			HttpServletRequest request, 
			@ModelAttribute CarouselDTO carousel) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (null == carousel.getTitle() || carousel.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		//check upload file.
		File file = new File(storePath + "/image/carousel.tmp");
		if (!file.exists()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("carousel image" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		carousel.setTitle(StringEscapeUtils.escapeHtml4(carousel.getTitle()));
	
		carousel.setDateline(System.currentTimeMillis());
		boolean result = newsService.addCarousel(carousel);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}


    @RequestMapping(
    		value = "/news/listCarousel", 
    		method = RequestMethod.GET)
	public Mono<ListCarouselVO> listCarousel(
			@RequestParam("activated") int activated, 
			@RequestParam("maxCount") int maxCount) {
		// TODO Auto-generated method stub
    	ListCarouselVO retValue = new ListCarouselVO();
    	
		if (activated != 0 && activated != 1) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("activated" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (maxCount <= 0 || maxCount >= 1024) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("max count" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		List<CarouselDTO> carousels = newsService.listCarousel(activated, maxCount);
		retValue.setCarousels(carousels);
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}

    @RequestMapping(
    		value = "/news/removeCarousel", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> removeCarousel(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = newsService.removeCarousel(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}

    @RequestMapping(
    		value = "/news/updateCarousel", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> saveCarousel(
			HttpServletRequest request, 
			@ModelAttribute CarouselDTO carousel) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (carousel.getId() <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == carousel.getTitle() || carousel.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		carousel.setTitle(StringEscapeUtils.escapeHtml4(carousel.getTitle()));
	
		carousel.setDateline(System.currentTimeMillis());
		boolean result = newsService.saveCarousel(carousel);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}

    @RequestMapping(
    		value = "/news/activateCarousel", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> activateCarousel(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = newsService.activateCarousel(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    //--------------------------------------news-------------------------------->
    @RequestMapping(
    		value = "/news/addNews", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> addNews(
			HttpServletRequest request, 
			@ModelAttribute NewsDTO news) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (null == news.getTitle() || news.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == news.getContent() || news.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("content" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		news.setTitle(StringEscapeUtils.escapeHtml4(news.getTitle()));
		news.setContent(StringEscapeUtils.escapeHtml4(news.getContent()));
		
		//check upload file.
		File file = new File(storePath + "/image/news.tmp");
		if (!file.exists()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("news picture" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
	
		news.setDateline(System.currentTimeMillis());
		boolean result = newsService.addNews(news);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/news/listNews", 
    		method = RequestMethod.GET)
	public Mono<ListNewsVO> listNews(
			@RequestParam("activated") int activated, 
			@RequestParam("maxCount") int maxCount) {
		// TODO Auto-generated method stub
    	ListNewsVO retValue = new ListNewsVO();
    	
		if (activated != 0 && activated != 1) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("activated" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (maxCount <= 0 || maxCount >= 1024) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("max count" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		List<NewsDTO> news = newsService.listNews(activated, maxCount);
		retValue.setNews(news);
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/news/removeNews", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> removeNews(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = newsService.removeNews(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/news/updateNews", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> saveNews(
			HttpServletRequest request, 
			@ModelAttribute NewsDTO news) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (news.getId() <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == news.getTitle() || news.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == news.getContent() || news.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		news.setTitle(StringEscapeUtils.escapeHtml4(news.getTitle()));
		news.setContent(StringEscapeUtils.escapeHtml4(news.getContent()));
	
		news.setDateline(System.currentTimeMillis());
		boolean result = newsService.updateNews(news);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/news/activateNews", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> activateNews(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = newsService.activateNews(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    //--------------------------------------product-------------------------------->
    @RequestMapping(
    		value = "/product/addProduct", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> addProduct(
			HttpServletRequest request, 
			@ModelAttribute ProductDTO product) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (null == product.getTitle() || product.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == product.getContent() || product.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("content" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		product.setTitle(StringEscapeUtils.escapeHtml4(product.getTitle()));
		product.setContent(StringEscapeUtils.escapeHtml4(product.getContent()));
		
		//check upload file.
		File file = new File(storePath + "/image/product.tmp");
		if (!file.exists()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("news picture" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
	
		product.setDateline(System.currentTimeMillis());
		boolean result = productService.addProduct(product);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/product/listProduct", 
    		method = RequestMethod.GET)
	public Mono<ListProductVO> listProduct(
			@RequestParam("activated") int activated, 
			@RequestParam("maxCount") int maxCount) {
		// TODO Auto-generated method stub
    	ListProductVO retValue = new ListProductVO();
    	
		if (activated != 0 && activated != 1) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("activated" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (maxCount <= 0 || maxCount >= 1024) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("max count" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		List<ProductDTO> products = productService.listProduct(activated, maxCount);
		retValue.setProducts(products);
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/product/removeProduct", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> removeProduct(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = productService.removeProduct(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/product/updateProduct", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> saveProduct(
			HttpServletRequest request, 
			@ModelAttribute ProductDTO product) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (product.getId() <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == product.getTitle() || product.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == product.getContent() || product.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		product.setTitle(StringEscapeUtils.escapeHtml4(product.getTitle()));
		product.setContent(StringEscapeUtils.escapeHtml4(product.getContent()));
	
		product.setDateline(System.currentTimeMillis());
		boolean result = productService.updateProduct(product);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/product/activateProduct", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> activateProduct(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = productService.activateProduct(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    

    //--------------------------------------customer-------------------------------->
    @RequestMapping(
    		value = "/customer/addCustomer", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> addCustomer(
			HttpServletRequest request, 
			@ModelAttribute CustomerDTO customer) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (null == customer.getTitle() || customer.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == customer.getContent() || customer.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("content" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		customer.setTitle(StringEscapeUtils.escapeHtml4(customer.getTitle()));
		customer.setContent(StringEscapeUtils.escapeHtml4(customer.getContent()));
		
		//check upload file.
		File file = new File(storePath + "/image/customer.tmp");
		if (!file.exists()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("customer picture" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
	
		customer.setDateline(System.currentTimeMillis());
		boolean result = customerService.add(customer);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/customer/listCustomer", 
    		method = RequestMethod.GET)
	public Mono<ListCustomerVO> listCustomer(
			@RequestParam("activated") int activated, 
			@RequestParam("maxCount") int maxCount) {
		// TODO Auto-generated method stub
    	ListCustomerVO retValue = new ListCustomerVO();
    	
		if (activated != 0 && activated != 1) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("activated" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (maxCount <= 0 || maxCount >= 1024) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("max count" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		List<CustomerDTO> customers = customerService.listCustomer(activated, maxCount);
		retValue.setCustomers(customers);
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/customer/removeCustomer", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> removeCustomer(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = customerService.remove(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/customer/updateCustomer", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> saveCustomer(
			HttpServletRequest request, 
			@ModelAttribute CustomerDTO customer) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (customer.getId() <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == customer.getTitle() || customer.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == customer.getContent() || customer.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		customer.setTitle(StringEscapeUtils.escapeHtml4(customer.getTitle()));
		customer.setContent(StringEscapeUtils.escapeHtml4(customer.getContent()));
	
		customer.setDateline(System.currentTimeMillis());
		boolean result = customerService.update(customer);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/customer/activateCustomer", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> activateCustomer(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = customerService.activate(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    //--------------------------------------contact-------------------------------->
    @RequestMapping(
    		value = "/contact/addContact", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> addContact(
			HttpServletRequest request, 
			@ModelAttribute ContactDTO contact) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (null == contact.getTitle() || contact.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == contact.getContent() || contact.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("content" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		contact.setTitle(StringEscapeUtils.escapeHtml4(contact.getTitle()));
		contact.setContent(StringEscapeUtils.escapeHtml4(contact.getContent()));
	
		contact.setDateline(System.currentTimeMillis());
		boolean result = contactService.addContact(contact);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/contact/listContact", 
    		method = RequestMethod.GET)
	public Mono<ListContactVO> listContact(
			@RequestParam("activated") int activated, 
			@RequestParam("maxCount") int maxCount) {
		// TODO Auto-generated method stub
    	ListContactVO retValue = new ListContactVO();
    	
		if (activated != 0 && activated != 1) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("activated" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (maxCount <= 0 || maxCount >= 1024) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("max count" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		List<ContactDTO> contacts = contactService.listContact(activated, maxCount);
		retValue.setContacts(contacts);
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/contact/removeContact", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> removeContact(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = contactService.removeContact(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/contact/updateContact", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> saveContact(
			HttpServletRequest request, 
			@ModelAttribute ContactDTO contact) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
		
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		if (contact.getId() <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == contact.getTitle() || contact.getTitle().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		
		if (null == contact.getContent() || contact.getContent().isEmpty()) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("title" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
		}
		contact.setTitle(StringEscapeUtils.escapeHtml4(contact.getTitle()));
		contact.setContent(StringEscapeUtils.escapeHtml4(contact.getContent()));
	
		contact.setDateline(System.currentTimeMillis());
		boolean result = contactService.updateContact(contact);
		if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
		}
		
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
		
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/contact/activateContact", 
    		method = RequestMethod.GET)
	public Mono<BaseVO> activateContact(
			HttpServletRequest request, 
			@RequestParam("id") int id) {
		// TODO Auto-generated method stub
		BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
    		retValue.setCode(CommonErrorDict.DENIED.getCode());
			retValue.setDescription(CommonErrorDict.DENIED.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	if (id <= 0) {
			retValue.setCode(CommonErrorDict.PARAMETER.getCode());
			retValue.setDescription("id" + CommonErrorDict.PARAMETER.getDescription());
			
			return Mono.just(retValue);
    	}
    	
    	boolean result = contactService.activateContact(id);
    	if (!result) {
			retValue.setCode(CommonErrorDict.DATABASE.getCode());
			retValue.setDescription(CommonErrorDict.DATABASE.getDescription());
			
			return Mono.just(retValue);
    	}
    	
		retValue.setCode(CommonErrorDict.OK.getCode());
		retValue.setDescription(CommonErrorDict.OK.getDescription());
    	
		return Mono.just(retValue);
	}
    
    private boolean isLogin(HttpServletRequest request) {
    	boolean retValue = false;
    	
    	HttpSession session = request.getSession();
    	
    	String token = (String)session.getAttribute("token");
    	if (null == token) {
    		return retValue;
    	}
    	
    	retValue = true;
    	
    	return retValue;
    }
}
