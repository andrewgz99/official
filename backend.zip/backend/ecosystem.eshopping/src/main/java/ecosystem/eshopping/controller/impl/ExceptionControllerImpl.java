package ecosystem.eshopping.controller.impl;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import ecosystem.common.dict.CommonErrorDict;
import ecosystem.common.exception.CommonException;
import ecosystem.common.vo.BaseVO;

@ControllerAdvice(basePackages = {"ecosystem.eshopping.controller"})
public class ExceptionControllerImpl {
	@ExceptionHandler(CommonException.class)
    @ResponseBody
    public String handleCommonException(CommonException e) {
        BaseVO retValue = new BaseVO();
        
        e.printStackTrace();
        retValue.setCode(e.getCode());
        retValue.setDescription(e.getDescription());
        
        return JSON.toJSONString(retValue);
    }
    
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public String handleException(Exception e) {
        BaseVO retValue = new BaseVO();

        e.printStackTrace();
        retValue.setCode(CommonErrorDict.SYSTEM.getCode());
        retValue.setDescription(CommonErrorDict.SYSTEM.getDescription());
        
        return JSON.toJSONString(retValue);
    }
}
