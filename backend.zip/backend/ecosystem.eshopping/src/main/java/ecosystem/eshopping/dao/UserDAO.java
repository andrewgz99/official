package ecosystem.eshopping.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import ecosystem.eshopping.model.dto.UserDTO;

@Repository
public interface UserDAO {
	UserDTO search(@Param("account") String account);
}
