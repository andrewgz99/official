package ecosystem.eshopping.service.impl;

import java.io.File;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ecosystem.eshopping.dao.ProductDAO;
import ecosystem.eshopping.model.dto.NewsDTO;
import ecosystem.eshopping.model.dto.ProductDTO;
import ecosystem.eshopping.service.ProductService;

@Service
public class ProductServiceImpl {
	@Value("${store.path}")
	private String storePath;
	
	@Autowired
	private ProductDAO productDAO;
	
	public boolean activateProduct(int id) {
		boolean retValue = false;
		
		int result = productDAO.activate(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public boolean removeProduct(int id) {
		boolean retValue = false;
		
		int result = productDAO.remove(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public boolean updateProduct(ProductDTO product) {
		boolean retValue = false;
		
		ProductDTO oldProduct = productDAO.search(product.getId());
		if (null == oldProduct) {
			return retValue;
		}
		
		String targetFileName = null;
		File file = new File(storePath + "/image/product.tmp");
		if (file.exists()) {
			String sourceFileName = "product.tmp";
			String sourceFilePath = storePath + "/image/" + sourceFileName;
			targetFileName = "product" + "_" + System.currentTimeMillis();
			String targetFilePath = storePath + "/image/";
			
	        File dir = new File(targetFilePath);
	       
	        boolean success = file.renameTo(new File(dir, targetFileName));
	        if (!success) {
	        	return retValue;
	        }
		}
		
		if (null != targetFileName && !targetFileName.isEmpty()) {
			product.setPicture(targetFileName);
		}
        
		int result = productDAO.update(product);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		if (null != targetFileName && !targetFileName.isEmpty()) {
			File oldDestFile = new File(storePath + "/image/" + oldProduct.getPicture());
			oldDestFile.delete();	
		}
		
		retValue = true;
		
		return retValue;
	}
	
	public List<ProductDTO> listProduct(int activated, int maxCount) {
		// TODO Auto-generated method stub
		List<ProductDTO> retValue = null;
		
		retValue = productDAO.listProduct(activated, maxCount);
		
		return retValue;
	}

	public boolean addProduct(ProductDTO product) {
		// TODO Auto-generated method stub
		boolean retValue = false;
		
		String sourceFileName = "product.tmp";
		String sourceFilePath = storePath + "/image/" + sourceFileName;
		String targetFileName = "product" + "_" + System.currentTimeMillis();
		String targetFilePath = storePath + "/image/";
		
        File file = new File(sourceFilePath);
        File dir = new File(targetFilePath);
       
        boolean success = file.renameTo(new File(dir, targetFileName));
        if (!success) {
        	return retValue;
        }
		
        product.setPicture(targetFileName);
		int result = productDAO.add(product);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		
		retValue = true;
		
		
		return retValue;
	}

}
