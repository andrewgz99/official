package ecosystem.eshopping.service.impl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ecosystem.eshopping.dao.NewsDAO;
import ecosystem.eshopping.model.dto.CarouselDTO;
import ecosystem.eshopping.model.dto.NewsDTO;
import ecosystem.eshopping.service.NewsService;

@Service
public class NewsServiceImpl implements NewsService {
	@Value("${store.path}")
	private String storePath;
	
	@Autowired
	private NewsDAO newsDAO;
	
	@Override
	public boolean updateNews(NewsDTO news) {
		boolean retValue = false;
		
		NewsDTO oldCarousel = newsDAO.searchNews(news.getId());
		if (null == oldCarousel) {
			return retValue;
		}
		
		String targetFileName = null;
		File file = new File(storePath + "/image/news.tmp");
		if (file.exists()) {
			String sourceFileName = "news.tmp";
			String sourceFilePath = storePath + "/image/" + sourceFileName;
			targetFileName = "news" + "_" + System.currentTimeMillis();
			String targetFilePath = storePath + "/image/";
			
	        File dir = new File(targetFilePath);
	       
	        boolean success = file.renameTo(new File(dir, targetFileName));
	        if (!success) {
	        	return retValue;
	        }	
		}
		
		if (null != targetFileName && !targetFileName.isEmpty()) {
			news.setPicture(targetFileName);
		}
        
		int result = newsDAO.updateNews(news);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		if (null != targetFileName && !targetFileName.isEmpty()) {
			File oldDestFile = new File(storePath + "/image/" + oldCarousel.getPicture());
			oldDestFile.delete();	
		}
		
		retValue = true;
		
		return retValue;
	}
	
	@Override
	public boolean removeNews(int id) {
		// TODO Auto-generated method stub
		boolean retValue = false;
		
		int result = newsDAO.removeNews(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public List<NewsDTO> listNews(int activated, int maxCount) {
		List<NewsDTO> retValue = null;
		
		retValue = newsDAO.listNews(activated, maxCount);
		
		return retValue;
	}
	
	public boolean addNews(NewsDTO news) {
		boolean retValue = false;
		
		String sourceFileName = "news.tmp";
		String sourceFilePath = storePath + "/image/" + sourceFileName;
		String targetFileName = "news" + "_" + System.currentTimeMillis();
		String targetFilePath = storePath + "/image/";
		
        File file = new File(sourceFilePath);
        File dir = new File(targetFilePath);
       
        boolean success = file.renameTo(new File(dir, targetFileName));
        if (!success) {
        	return retValue;
        }
		
        news.setPicture(targetFileName);
		int result = newsDAO.addNews(news);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		
		retValue = true;
		
		
		return retValue;
	}

	@Override
	public boolean saveCarousel(CarouselDTO carousel) {
		// TODO Auto-generated method stub
		boolean retValue = false;
		
		CarouselDTO oldCarousel = newsDAO.searchCarousel(carousel.getId());
		if (null == oldCarousel) {
			return retValue;
		}
		
		String targetFileName = null;
		File file = new File(storePath + "/image/carousel.tmp");
		if (file.exists()) {
			String sourceFileName = "carousel.tmp";
			String sourceFilePath = storePath + "/image/" + sourceFileName;
			targetFileName = "carousel" + "_" + System.currentTimeMillis();
			String targetFilePath = storePath + "/image/";
			
	        File dir = new File(targetFilePath);
	       
	        boolean success = file.renameTo(new File(dir, targetFileName));
	        if (!success) {
	        	return retValue;
	        }	
		}
		
		if (null != targetFileName && !targetFileName.isEmpty()) {
			carousel.setPicture(targetFileName);
		}
        
		int result = newsDAO.updateCarousel(carousel);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		if (null != targetFileName && !targetFileName.isEmpty()) {
			File oldDestFile = new File(storePath + "/image/" + oldCarousel.getPicture());
			oldDestFile.delete();	
		}
		
		retValue = true;
		
		return retValue;
	}
	
	@Override
	public boolean addCarousel(CarouselDTO carousel) {
		// TODO Auto-generated method stub
		boolean retValue = false;

		String sourceFileName = "carousel.tmp";
		String sourceFilePath = storePath + "/image/" + sourceFileName;
		String targetFileName = "carousel" + "_" + System.currentTimeMillis();
		String targetFilePath = storePath + "/image/";
		
        File file = new File(sourceFilePath);
        File dir = new File(targetFilePath);
       
        boolean success = file.renameTo(new File(dir, targetFileName));
        if (!success) {
        	return retValue;
        }
		
        carousel.setPicture(targetFileName);
		int result = newsDAO.addCarousel(carousel);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		
		retValue = true;
		
		return retValue;
	}

	@Override
	public List<CarouselDTO> listCarousel(int activated, int maxCount) {
		// TODO Auto-generated method stub
		List<CarouselDTO> retValue = null;
		
 		retValue = newsDAO.listCarousel(activated, maxCount);
		
		return retValue;
	}

	@Override
	public boolean removeCarousel(int id) {
		// TODO Auto-generated method stub
		boolean retValue = false;
		
		int result = newsDAO.removeCarousel(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}

	@Override
	public boolean activateCarousel(int id) {
		// TODO Auto-generated method stub
		boolean retValue = false;
		
		int result = newsDAO.activateCarousel(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	@Override
	public boolean activateNews(int id) {
		boolean retValue = false;
		
		int result = newsDAO.activateNews(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
}
