package ecosystem.eshopping.service.impl;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ecosystem.eshopping.dao.IntroductionDAO;
import ecosystem.eshopping.model.dto.IntroductionDTO;

@Service
public class IntroductionServiceImpl {
	@Autowired
	private IntroductionDAO introductionDAO;
	
	@Value("${store.path}")
	private String storePath;
	
	public boolean activate() {
		boolean retValue = false;
		
		if (introductionDAO.activate() >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public boolean change(IntroductionDTO introduction) {
		boolean retValue = false;
		
		String targetFileName = null;
		File file = new File(storePath + "/image/introduction.tmp");
		if (file.exists()) {
			String sourceFileName = "introduction.tmp";
			String sourceFilePath = storePath + "/image/" + sourceFileName;
			targetFileName = "introduction" + "_" + System.currentTimeMillis();
			String targetFilePath = storePath + "/image/";
			
	        File dir = new File(targetFilePath);
	       
	        boolean success = file.renameTo(new File(dir, targetFileName));
	        if (!success) {
	        	return retValue;
	        }	
		}
		
		if (null != targetFileName && !targetFileName.isEmpty()) {
			introduction.setPicture(targetFileName);
		}
		
		int result = introductionDAO.update(introduction);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public IntroductionDTO searchUs() {
		IntroductionDTO retValue = null;
		
		retValue = introductionDAO.search();
		
		return retValue;
	}
	
	
}
