package ecosystem.eshopping;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

/**
 * 
 * @author robert
 *
 */
@SpringBootApplication
@ComponentScan("ecosystem.eshopping")
@MapperScan("ecosystem.eshopping.dao")
@ImportResource({"classpath:spring.xml"})
public class Application {
    private static Logger logger = LoggerFactory.getLogger(Application.class);
    
    public static void main(String[] args) {
        logger.debug("eshopping is going to start...");
        
        SpringApplication.run(Application.class, args);
        
        logger.debug("eshopping is started...");
    }
}
