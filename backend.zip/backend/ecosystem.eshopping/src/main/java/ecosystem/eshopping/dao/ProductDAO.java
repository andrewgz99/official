package ecosystem.eshopping.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import ecosystem.eshopping.model.dto.ProductDTO;

@Repository
public interface ProductDAO {
	int activate(@Param("id") int id);
	
	int remove(@Param("id") int id);
	
	int add(@Param("product") ProductDTO product);
	
	int update(@Param("product") ProductDTO product);
	
	ProductDTO search(@Param("id") int id);
	
	List<ProductDTO> listProduct(
			@Param("activated") int activated, @Param("maxCount") int maxCount);
}
