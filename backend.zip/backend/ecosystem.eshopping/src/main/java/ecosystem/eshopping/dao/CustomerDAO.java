package ecosystem.eshopping.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import ecosystem.eshopping.model.dto.CustomerDTO;
import ecosystem.eshopping.model.dto.ProductDTO;

@Repository
public interface CustomerDAO {
	int activate(@Param("id") int id);
	
	int remove(@Param("id") int id);
	
	int add(@Param("customer") CustomerDTO customer);
	
	int update(@Param("customer") CustomerDTO product);
	
	CustomerDTO search(@Param("id") int id);
	
	List<CustomerDTO> listCustomer(
			@Param("activated") int activated, @Param("maxCount") int maxCount);
}
