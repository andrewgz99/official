package ecosystem.eshopping.service.impl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ecosystem.eshopping.dao.CustomerDAO;
import ecosystem.eshopping.dao.ProductDAO;
import ecosystem.eshopping.model.dto.CustomerDTO;
import ecosystem.eshopping.model.dto.ProductDTO;

@Service
public class CustomerServiceImpl {
	@Value("${store.path}")
	private String storePath;
	
	@Autowired
	private CustomerDAO customerDAO;
	
	public boolean activate(int id) {
		boolean retValue = false;
		
		int result = customerDAO.activate(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public boolean remove(int id) {
		boolean retValue = false;
		
		int result = customerDAO.remove(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public boolean update(CustomerDTO customer) {
		boolean retValue = false;
		
		CustomerDTO oldCustomer = customerDAO.search(customer.getId());
		if (null == oldCustomer) {
			return retValue;
		}
		
		String targetFileName = null;
		File file = new File(storePath + "/image/customer.tmp");
		if (file.exists()) {
			String sourceFileName = "customer.tmp";
			String sourceFilePath = storePath + "/image/" + sourceFileName;
			targetFileName = "customer" + "_" + System.currentTimeMillis();
			String targetFilePath = storePath + "/image/";
			
	        File dir = new File(targetFilePath);
	       
	        boolean success = file.renameTo(new File(dir, targetFileName));
	        if (!success) {
	        	return retValue;
	        }
		}
		
		if (null != targetFileName && !targetFileName.isEmpty()) {
			customer.setPicture(targetFileName);
		}
        
		int result = customerDAO.update(customer);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		if (null != targetFileName && !targetFileName.isEmpty()) {
			File oldDestFile = new File(storePath + "/image/" + oldCustomer.getPicture());
			oldDestFile.delete();	
		}
		
		retValue = true;
		
		return retValue;
	}
	
	public List<CustomerDTO> listCustomer(int activated, int maxCount) {
		// TODO Auto-generated method stub
		List<CustomerDTO> retValue = null;
		
		retValue = customerDAO.listCustomer(activated, maxCount);
		
		return retValue;
	}

	public boolean add(CustomerDTO product) {
		// TODO Auto-generated method stub
		boolean retValue = false;
		
		String sourceFileName = "customer.tmp";
		String sourceFilePath = storePath + "/image/" + sourceFileName;
		String targetFileName = "customer" + "_" + System.currentTimeMillis();
		String targetFilePath = storePath + "/image/";
		
        File file = new File(sourceFilePath);
        File dir = new File(targetFilePath);
       
        boolean success = file.renameTo(new File(dir, targetFileName));
        if (!success) {
        	return retValue;
        }
		
        product.setPicture(targetFileName);
		int result = customerDAO.add(product);
		if (1 != result) {
			File destFile = new File(storePath + "/image/" + targetFileName);
			destFile.delete();
			
			return retValue;
		}
		
		retValue = true;
		
		
		return retValue;
	}
}
