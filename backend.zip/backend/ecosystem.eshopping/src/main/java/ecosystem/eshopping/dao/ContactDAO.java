package ecosystem.eshopping.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import ecosystem.eshopping.model.dto.ContactDTO;

@Repository
public interface ContactDAO {
	int activate(@Param("id") int id);
	
	int remove(@Param("id") int id);
	
	int add(@Param("contact") ContactDTO contact);
	
	int update(@Param("contact") ContactDTO product);
	
	ContactDTO search(@Param("id") int id);
	
	List<ContactDTO> listContact(
			@Param("activated") int activated, @Param("maxCount") int maxCount);
}
