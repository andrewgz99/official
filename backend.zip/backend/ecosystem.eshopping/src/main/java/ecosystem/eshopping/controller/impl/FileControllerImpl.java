package ecosystem.eshopping.controller.impl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import ecosystem.common.dict.CommonErrorDict;
import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.service.NewsService;
import reactor.core.publisher.Mono;

@CrossOrigin(
	    origins = {"*"},
	    maxAge = 3600,
	    allowCredentials = "true")
@RestController
@RequestMapping("/store")
public class FileControllerImpl {
	@Value("${store.path}")
	private String storePath;
	
	@Autowired
	private NewsService newsService;
	
    @PostMapping(value = "/upload", 
    		consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
    		produces = MediaType.APPLICATION_JSON_VALUE)
	public Mono<BaseVO> uploadCarousel(
			HttpServletRequest request, 
			@RequestParam("file") MultipartFile file, 
			@RequestParam("name") String name) {
		// TODO Auto-generated method stub
    	BaseVO retValue = new BaseVO();
    	
    	if (!isLogin(request)) {
	        retValue.setCode(CommonErrorDict.DENIED.getCode());
	        retValue.setDescription(CommonErrorDict.DENIED.getDescription());
	        
	        return Mono.just(retValue);
    	}
    	
        try{  
	        byte barr[]=file.getBytes();  
	        
	        new File(storePath + "/image/" + name).delete();
	        
	        BufferedOutputStream bout=new BufferedOutputStream(  
	                 new FileOutputStream(storePath + "/image/" + name));  
	        bout.write(barr);  
	        bout.flush();  
	        bout.close();
	        
	        retValue.setCode(CommonErrorDict.OK.getCode());
	        retValue.setDescription(CommonErrorDict.OK.getDescription());
        } catch(Exception ex) {
        	ex.printStackTrace();
        	
	        retValue.setCode(CommonErrorDict.SYSTEM.getCode());
	        retValue.setDescription(CommonErrorDict.SYSTEM.getDescription());
        }
	    	
		return Mono.just(retValue);
	}
    
    @RequestMapping(
    		value = "/download", 
    		method = RequestMethod.GET, 
    		produces = MediaType.IMAGE_PNG_VALUE)
    public byte[] downloadCarousel(
    		HttpServletResponse response, 
    		@RequestParam("name") String name
    		) {
    	byte[] retValue = null;
    	
        File file;
		try {
	        file = new File(storePath + "/image/" + name);
	        if (!file.exists()) {
	        	return retValue;
	        }
	        
	        retValue = FileUtils.readFileToByteArray(file);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return retValue;
    }
    
    private boolean isLogin(HttpServletRequest request) {
    	boolean retValue = false;
    	
    	HttpSession session = request.getSession();
    	
    	String token = (String)session.getAttribute("token");
    	if (null == token) {
    		return retValue;
    	}
    	
    	retValue = true;
    	
    	return retValue;
    }
}
