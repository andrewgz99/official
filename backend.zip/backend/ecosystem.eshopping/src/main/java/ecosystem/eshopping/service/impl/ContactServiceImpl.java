package ecosystem.eshopping.service.impl;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ecosystem.eshopping.dao.ContactDAO;
import ecosystem.eshopping.dao.ProductDAO;
import ecosystem.eshopping.model.dto.ContactDTO;
import ecosystem.eshopping.model.dto.ProductDTO;

@Service
public class ContactServiceImpl {
	@Value("${store.path}")
	private String storePath;
	
	@Autowired
	private ContactDAO contactDAO;
	
	public boolean activateContact(int id) {
		boolean retValue = false;
		
		int result = contactDAO.activate(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public boolean removeContact(int id) {
		boolean retValue = false;
		
		int result = contactDAO.remove(id);
		if (result >= 0) {
			retValue = true;
		}
		
		return retValue;
	}
	
	public boolean updateContact(ContactDTO contact) {
		boolean retValue = false;
		
		ContactDTO oldContact = contactDAO.search(contact.getId());
		if (null == oldContact) {
			return retValue;
		}
        
		int result = contactDAO.update(contact);
		if (1 != result) {			
			return retValue;
		}
		
		retValue = true;
		
		return retValue;
	}
	
	public List<ContactDTO> listContact(int activated, int maxCount) {
		// TODO Auto-generated method stub
		List<ContactDTO> retValue = null;
		
		retValue = contactDAO.listContact(activated, maxCount);
		
		return retValue;
	}

	public boolean addContact(ContactDTO contact) {
		// TODO Auto-generated method stub
		boolean retValue = false;
		
		int result = contactDAO.add(contact);
		if (1 != result) {
			return retValue;
		}
		
		retValue = true;
		
		return retValue;
	}
}
