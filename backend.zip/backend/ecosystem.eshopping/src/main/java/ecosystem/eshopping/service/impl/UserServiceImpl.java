package ecosystem.eshopping.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ecosystem.eshopping.dao.UserDAO;
import ecosystem.eshopping.model.dto.UserDTO;

@Service
public class UserServiceImpl {
	@Autowired
	private UserDAO userDAO;
	
	public UserDTO searchUser(String account) {
		UserDTO retValue = null;
		
		retValue = userDAO.search(account);
		
		return retValue;
	}
}
