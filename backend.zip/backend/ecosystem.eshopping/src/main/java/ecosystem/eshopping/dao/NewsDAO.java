package ecosystem.eshopping.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import ecosystem.eshopping.model.dto.CarouselDTO;
import ecosystem.eshopping.model.dto.NewsDTO;

@Repository
public interface NewsDAO {
	int activateCarousel(@Param("id") int id);
	
	int updateCarousel(@Param("carousel") CarouselDTO carousel);
	
	CarouselDTO searchCarousel(@Param("id") int id);
	
	int removeCarousel(@Param("id") int id);
	
	int addCarousel(@Param("carousel") CarouselDTO carousel);
	
	int activateNews(@Param("id") int id);
	
	int updateNews(@Param("news") NewsDTO news);
	
	int removeNews(@Param("id") int id);
	
	NewsDTO searchNews(@Param("id") int id);
	
	int addNews(@Param("news") NewsDTO news);
	
	List<NewsDTO> listNews(
			@Param("activated") int activated, @Param("maxCount")  int maxCount);
	
	List<CarouselDTO> listCarousel(
			@Param("activated") int activated, 
			@Param("maxCount") int maxCount);
}
