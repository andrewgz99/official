package ecosystem.eshopping;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;

import ecosystem.eshopping.dao.InitializerDAO;
import ecosystem.eshopping.dao.NewsDAO;
import ecosystem.eshopping.model.dto.CarouselDTO;
import ecosystem.eshopping.model.dto.NewsDTO;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class Tester {
	
	@Autowired
	private NewsDAO newsDAO;
	
	@Autowired
	private InitializerDAO initializerDAO;
	
	@Test
	public void testNews() {
		List<CarouselDTO> carousels = newsDAO.listCarousel(0, 1000);
		
		for (CarouselDTO carousel : carousels) {
			System.out.println("carousel->" + JSON.toJSONString(carousel));
		}
	}
	
	@Test
	public void testBoot2() throws Exception {
		int result;
		
		initializerDAO.createContact();
		initializerDAO.createCustomer();
		initializerDAO.createIntroduction();
		initializerDAO.createProduct();
		
		result = initializerDAO.createNews();
		System.out.println("result->" + result);

		
		NewsDTO newsDTO = new NewsDTO();
		newsDTO.setTitle("hi你好");
		newsDTO.setContent("wo he好");
		newsDTO.setPicture("http://abc");
		newsDTO.setDateline(System.currentTimeMillis());
		result = newsDAO.addNews(newsDTO);
		System.out.println("result->" + result);
		
		List<NewsDTO> newsList = newsDAO.listNews(1, 100);
		System.out.println("size of news list->" + newsList.size());
		for (NewsDTO news : newsList) {
			System.out.println("id->" + news.getId() + ", title->" + news.getTitle() + 
					", content->" + news.getContent() + ", picture->" + news.getPicture() +
					", dateline->" + news.getDateline());
		}
	}

}
