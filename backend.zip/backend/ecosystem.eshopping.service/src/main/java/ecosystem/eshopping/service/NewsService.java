package ecosystem.eshopping.service;

import java.util.List;

import ecosystem.eshopping.model.dto.CarouselDTO;
import ecosystem.eshopping.model.dto.NewsDTO;

public interface NewsService {
	boolean updateNews(NewsDTO news);
	
	boolean removeNews(int id);
	
	List<NewsDTO> listNews(int activated, int maxCount);
	
	boolean activateNews(int id);
	
	boolean addNews(NewsDTO news);
	
	boolean activateCarousel(int id);
	
	boolean saveCarousel(CarouselDTO carousel);
	
	boolean removeCarousel(int id);
	
	boolean addCarousel(CarouselDTO carousel);
	
	List<CarouselDTO> listCarousel(int activated, int maxCount);
}
