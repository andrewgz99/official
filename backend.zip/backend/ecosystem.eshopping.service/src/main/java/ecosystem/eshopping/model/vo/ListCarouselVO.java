package ecosystem.eshopping.model.vo;

import java.util.List;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.CarouselDTO;

public class ListCarouselVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<CarouselDTO> carousels;

	public List<CarouselDTO> getCarousels() {
		return carousels;
	}

	public void setCarousels(List<CarouselDTO> carousels) {
		this.carousels = carousels;
	}
}
