package ecosystem.eshopping.service;

import java.util.List;

import ecosystem.eshopping.model.dto.ProductDTO;
import ecosystem.eshopping.model.vo.ProductsVO;

public interface ProductService {
	List<ProductDTO> searchProducts(int maxCount);
	
	boolean addProduct(ProductDTO product);
}
