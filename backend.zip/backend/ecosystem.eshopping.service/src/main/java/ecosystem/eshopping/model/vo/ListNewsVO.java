package ecosystem.eshopping.model.vo;

import java.util.List;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.NewsDTO;

public class ListNewsVO extends BaseVO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<NewsDTO> news;

	public List<NewsDTO> getNews() {
		return news;
	}

	public void setNews(List<NewsDTO> news) {
		this.news = news;
	}
	
	
}
