package ecosystem.eshopping.model.vo;

import java.util.List;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.CustomerDTO;

public class ListCustomerVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<CustomerDTO> customers;

	public List<CustomerDTO> getCustomers() {
		return customers;
	}

	public void setCustomers(List<CustomerDTO> customers) {
		this.customers = customers;
	}
	
	

}
