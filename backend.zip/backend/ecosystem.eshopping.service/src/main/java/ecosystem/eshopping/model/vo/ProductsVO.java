package ecosystem.eshopping.model.vo;

import java.util.List;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.ProductDTO;

public class ProductsVO extends BaseVO {
	private List<ProductDTO> products;

	public List<ProductDTO> getProducts() {
		return products;
	}

	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	
	
}
