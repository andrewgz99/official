package ecosystem.eshopping.model.vo;

import java.util.List;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.ProductDTO;

public class ListProductVO extends BaseVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<ProductDTO> products;

	public List<ProductDTO> getProducts() {
		return products;
	}

	public void setProducts(List<ProductDTO> products) {
		this.products = products;
	}
	
	
}
