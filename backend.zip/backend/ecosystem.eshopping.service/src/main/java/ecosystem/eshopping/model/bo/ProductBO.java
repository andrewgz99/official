package ecosystem.eshopping.model.bo;

import ecosystem.common.bo.BaseBO;

public class ProductBO extends BaseBO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
