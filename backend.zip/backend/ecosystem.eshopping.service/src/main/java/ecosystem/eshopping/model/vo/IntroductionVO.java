package ecosystem.eshopping.model.vo;

import ecosystem.common.vo.BaseVO;
import ecosystem.eshopping.model.dto.IntroductionDTO;

public class IntroductionVO extends BaseVO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private IntroductionDTO introduction;

	public IntroductionDTO getIntroduction() {
		return introduction;
	}

	public void setIntroduction(IntroductionDTO introduction) {
		this.introduction = introduction;
	}
	
	
}
